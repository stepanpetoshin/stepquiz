class Quiz:


    def __init__(self, quiz_id, quiz_type, db):
        self.quiz_id = quiz_id
        self.quiz_type = quiz_type
        self.db = db

        self.questions = self.sort_questions()
        self.answers = self.sort_answers('answers')
        self.show = self.show_answers()
        self.right_answers = self.sort_answers('correct_answers')

    def get_quiz_collection(self):
        return self.db.collection('quiz').document(self.quiz_type).collection(self.quiz_id)

    def sort_questions(self):
        questions_dict = self.get_quiz_collection().document('questions').get().to_dict()

        questions_keys = questions_dict.keys()
        questions_keys = sorted(questions_keys, key=lambda x: int(x[1:]))

        return [questions_dict[key] for key in questions_keys]

    def sort_answers(self, answer_type):
        answers_dict = self.get_quiz_collection().document(answer_type).get().to_dict()
        answers_keys = answers_dict.keys()

        answers_keys = sorted(answers_keys, key=lambda x: int(x[1:]))

        return [answers_dict[key] for key in answers_keys]

    def show_answers(self):
        setting = self.get_quiz_collection().document('setting').get().to_dict()
        setting_values = setting['show']

        return setting_values
