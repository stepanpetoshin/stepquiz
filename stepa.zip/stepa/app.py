from flask import Flask, render_template, request, redirect, url_for, flash, session
import firebase_handler as fh
import re

app = Flask(__name__)
app.secret_key = 'stepa_project'


@app.route('/')
def home():
    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)


@app.route('/student_login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        student_id = request.form['student_id']
        if fh.check_student_id(student_id):
            session['user_id'] = student_id
            return redirect(url_for('student', student_id=student_id))

        else:
            return redirect(url_for('home') + '?error=notfound')
    else:
        return redirect(url_for('home'))


@app.route('/teacher_login', methods=['GET', 'POST'])
def teacher_login():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        if fh.check_teacher_id(teacher_id):
            session['user_id'] = teacher_id
            return redirect(url_for('teacher', teacher_id=teacher_id))

        else:
            return redirect(url_for('home') + '?error=notfound')
    else:
        return redirect(url_for('home'))


@app.route('/teacher')
def teacher():
    return render_template('teacher.html')


@app.route('/student')
def student():
    return render_template('student.html')


@app.route('/quiz')
def quiz():
    questions, answers, correct_answers, quiz_id = fh.get_random_quiz()
    session['current_quiz'] = quiz_id
    return render_template('quiz.html', questions=questions, answers=answers, correct_answers=correct_answers)


@app.route('/verify_quiz_code', methods=['GET', 'POST'])
def verify_quiz_code():
    if request.method == 'POST':
        quiz_code = request.form['quizCode']
        quiz = fh.get_quiz_by_code(quiz_code)

        if quiz:
            session['current_quiz'] = quiz_code
            if quiz.show:
                return render_template('quiz.html', questions=quiz.questions, answers=quiz.answers,
                                       correct_answers=quiz.right_answers)
            else:
                return render_template('private_quiz.html', questions=quiz.questions, answers=quiz.answers,
                                       correct_answers=quiz.right_answers)
        else:
            return redirect(url_for('student') + '?error=notfound')


@app.route('/create_quiz_template')
def create_quiz_template():
    return render_template('create_quiz.html')


@app.route('/create_quiz', methods=['GET', 'POST'])
def create_quiz():
    fh.check_existing_fields(session['user_id'], 'teacher')
    quiz_name = request.form['quizName']

    num_questions = int(request.form['numQuestions'])
    share_answers = 'shareAnswers' in request.form
    make_public = 'makePublic' in request.form

    meta_data = []
    re_pattern = r'\s*;\s*'
    for i in range(1, num_questions + 1):
        question_text = request.form[f'question{i}']
        question_type = request.form[f'question{i}Type']
        answers = re.split(re_pattern, request.form[f'answers{i}'])
        correct_answers = re.split(re_pattern, request.form[f'rightAnswer{i}'])


        meta_data.append({
            'text': question_text,
            'type': question_type,
            'answers': answers,
            'correct_answers': correct_answers
        })

    quiz = fh.create_quiz_dictionary(meta_data, share_answers, quiz_name)
    quiz_id = fh.save_created_quiz(quiz, session['user_id'], make_public)

    return redirect(url_for('teacher') + f'?quiz_id={quiz_id}')

@app.route('/student_quiz_completed', methods=['GET', 'POST'])
def student_quiz_completed():
    score = float(request.form['score']) / 100
    if session['current_quiz']:
        fh.save_results(session['user_id'], session['current_quiz'], score)

    return render_template('student.html')


@app.route('/my_progress')
def my_progress():
    results = fh.get_data_about_completed_quizzes(session['user_id'])

    return render_template('my_progress.html', quizzes=results)


@app.route('/my_quizzes')
def my_quizzes():
    quizzes = fh.get_summary_about_created_quizzes(session['user_id'])
    return render_template('my_quizzes.html', quizzes=quizzes)


@app.route('/quiz_results', methods=['GET', 'POST'])
def quiz_results():
    quiz_id = request.form['quiz_id']
    results, name = fh.get_created_quiz_results(quiz_id)
    return render_template('quiz_results.html', results=results, quiz_name=name)
