import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import quiz as q
import random
from datetime import datetime

cred = credentials.Certificate('stepa-project-firebase-adminsdk-h4xii-d63edb29d9.json')
firebase_admin.initialize_app(cred)

db = firestore.client()


def check_student_id(student_id):
    # Assuming 'students' is your collection
    students_profiles_ref = db.collection('students_profiles')
    student_ids = [doc.id for doc in students_profiles_ref.stream()]

    if student_id in student_ids:
        # Student ID exists
        return True
    else:
        # Student ID does not exist
        return False


def check_teacher_id(teacher_id):
    # Assuming 'students' is your collection
    teachers_profiles_ref = db.collection('teachers_profiles')
    teacher_ids = [doc.id for doc in teachers_profiles_ref.stream()]

    if teacher_id in teacher_ids:
        # Student ID exists
        return True
    else:
        # Student ID does not exist
        return False


def get_random_quiz():
    quiz_ids = db.collection('quiz').document('quiz-ids').get()
    quiz_ids = quiz_ids.to_dict()
    selected_id = random.choice(quiz_ids['public'])

    quiz = q.Quiz(selected_id, 'public', db)
    return quiz.questions, quiz.answers, quiz.right_answers, selected_id


def get_quiz_by_code(access_code):
    quiz_ids = db.collection('quiz').document('quiz-ids').get()
    quiz_ids = quiz_ids.to_dict()
    private_ids = quiz_ids['private']
    public_ids = quiz_ids['public']
    if access_code in private_ids:
        quiz = q.Quiz(access_code, 'private', db)
        return quiz
    elif access_code in public_ids:
        quiz = q.Quiz(access_code, 'public', db)
        return quiz

    else:
        return None


def extract_quiz_data(meta_data):
    questions = []
    answers = []
    correct_answers = []

    for question_data in meta_data:
        type = question_data['type']

        if type == 'choice':
            question_text = question_data['text']
            if question_text[-1] == '?':
                question_text += 'm'
            else:
                question_text += '?m'
            questions.append(question_text)

            answers_text = question_data['answers']

            answers.append(answers_text)
            correct_answers.append(question_data['correct_answers'])

        else:
            question_text = question_data['text']
            if question_text[-1] != '?':
                question_text += '?'
            questions.append(question_text)
            correct_answer_text = [question_data['correct_answers'][0]]
            answers.append(correct_answer_text)
            correct_answers.append(question_data['correct_answers'])

    return questions, answers, correct_answers


def create_quiz_dictionary(meta_data, share_answers, name):
    questions, answers, correct_answers = extract_quiz_data(meta_data)
    setting = share_answers

    questions_dictionary = {f'q{i}': element for i, element in enumerate(questions, start=1)}
    answers_dictionary = {f'q{i}': element for i, element in enumerate(answers, start=1)}
    correct_answers_dictionary = {f'q{i}': element for i, element in enumerate(correct_answers, start=1)}

    quiz_dictionary = {
        'questions': questions_dictionary,
        'answers': answers_dictionary,
        'correct_answers': correct_answers_dictionary,
        'setting': {'show': setting, 'name': name}
    }

    return quiz_dictionary


def save_created_quiz(quiz, uid, public):
    print(quiz)
    quiz_id = ''.join(quiz['setting']['name'].split()) + datetime.now().strftime('%m%d%y')

    teacher_ref = db.collection('teachers_profiles').document(uid).get().to_dict()
    teacher_name = teacher_ref['name']
    quiz['setting']['created_by'] = teacher_name

    quiz_type = 'private'
    if public:
        quiz_type = 'public'

    private_quizzes_ref = db.collection('quiz').document(quiz_type)
    private_quizzes_ref.collection(quiz_id).document("questions").set(quiz['questions'])
    private_quizzes_ref.collection(quiz_id).document("answers").set(quiz['answers'])
    private_quizzes_ref.collection(quiz_id).document("correct_answers").set(quiz['correct_answers'])
    private_quizzes_ref.collection(quiz_id).document("setting").set(quiz['setting'])

    quiz_ids_ref = db.collection('quiz').document('quiz-ids').get().to_dict()
    quiz_ids_ref[quiz_type].append(quiz_id)
    db.collection('quiz').document('quiz-ids').set(quiz_ids_ref)

    if not check_existing_fields(uid, 'teacher'):
        teacher_ref['quizzes_created'] = [quiz_id]
        db.collection('teachers_profiles').document(uid).set(teacher_ref)

    else:
        teacher_ref['quizzes_created'].append(quiz_id)
        db.collection('teachers_profiles').document(uid).set(teacher_ref)

    return quiz_id


def check_quiz_type(quiz_id):
    quizzes_ids = db.collection('quiz').document('quiz-ids').get().to_dict()

    if quiz_id in quizzes_ids['private']:
        return 'private'
    else:
        return 'public'


def check_for_results(quiz_type, quiz_id):
    docs = db.collection('quiz').document(quiz_type).collection(quiz_id).stream()
    for doc in docs:
        if doc.id == 'results':
            return True
    return False


def track_quiz_results(quiz_id, uid, score):
    quiz_type = check_quiz_type(quiz_id)
    results_present = check_for_results(quiz_type, quiz_id)

    if results_present:
        quizzes_res = db.collection('quiz').document(quiz_type).collection(quiz_id).document('results').get().to_dict()
        quizzes_res[uid] = score
        db.collection('quiz').document(quiz_type).collection(quiz_id).document('results').set(quizzes_res)
    else:
        db.collection('quiz').document(quiz_type).collection(quiz_id).document('results').set({uid: score})


def check_existing_fields(uid, role):
    if role == 'student':

        students_ref = db.collection('students_profiles').document(uid).get().to_dict()

        if 'quizzes_completed' not in students_ref.keys():
            return False

    elif role == 'teacher':

        teachers_ref = db.collection('teachers_profiles').document(uid).get().to_dict()
        if 'quizzes_created' not in teachers_ref.keys():
            return False

    return True


def save_results(uid, quiz_id, score):
    if not check_existing_fields(uid, 'student'):

        students_ref = db.collection('students_profiles').document(uid).get().to_dict()
        students_ref['quizzes_completed'] = {quiz_id: score}
        db.collection('students_profiles').document(uid).set(students_ref)
        track_quiz_results(quiz_id, uid, score)

    else:

        students_ref = db.collection('students_profiles').document(uid).get().to_dict()

        students_ref['quizzes_completed'][quiz_id] = score
        db.collection('students_profiles').document(uid).set(students_ref)
        track_quiz_results(quiz_id, uid, score)


def get_data_about_completed_quizzes(uid):
    student_ref = db.collection('students_profiles').document(uid).get().to_dict()
    public_quizzes_ids = db.collection('quiz').document('quiz-ids').get().to_dict()['public']
    private_quizzes_ref = db.collection('quiz').document('private')
    public_quizzes_ref = db.collection('quiz').document('public')

    quizzes_completed = student_ref['quizzes_completed']
    quizzes_data = []

    for quiz_id in quizzes_completed:
        if quiz_id in public_quizzes_ids:
            quiz_data = public_quizzes_ref.collection(quiz_id).document('setting').get().to_dict()
            quizzes_data.append(
                {
                    'id': quiz_id,
                    'name': quiz_data['name'],
                    'score': f'{quizzes_completed[quiz_id] * 100}%',
                    'created': 'Public Quiz'
                }
            )
        else:
            quiz_data = private_quizzes_ref.collection(quiz_id).document('setting').get().to_dict()
            quizzes_data.append(
                {
                    'id': quiz_id,
                    'name': quiz_data['name'],
                    'score': f'{quizzes_completed[quiz_id] * 100}%',
                    'created': quiz_data['created_by']
                }
            )

    return quizzes_data


def get_summary_about_created_quizzes(uid):
    created_quizzes = db.collection('teachers_profiles').document(uid).get().to_dict()['quizzes_created']
    quizzes_ref = db.collection('quiz')
    public_quizzes_ids = quizzes_ref.document('quiz-ids').get().to_dict()['public']

    quizzes_summary = []
    for quiz_id in created_quizzes:

        if quiz_id in public_quizzes_ids:
            quiz = quizzes_ref.document('public').collection(quiz_id).document('setting').get().to_dict()
            quiz_res = quizzes_ref.document('public').collection(quiz_id).document('results').get()
            results = 0
            if quiz_res.exists:
                results = len(quiz_res.to_dict().keys())
            quizzes_summary.append({
                'id': quiz_id,
                'name': quiz['name'],
                'num_completions': results
            })
        else:
            quiz = quizzes_ref.document('private').collection(quiz_id).document('setting').get().to_dict()
            quiz_res = quizzes_ref.document('private').collection(quiz_id).document('results').get()
            results = 0
            if quiz_res.exists:
                results = len(quiz_res.to_dict().keys())
            quizzes_summary.append({
                'id': quiz_id,
                'name': quiz['name'],
                'num_completions': results
            })

    return quizzes_summary


def get_name_id_pair():
    name_id = {}

    for person in db.collection('students_profiles').stream():
        name_id[person.id] = db.collection('students_profiles').document(person.id).get().to_dict()['name']

    return name_id


def get_created_quiz_results(quiz_id):
    quizzes_ref = db.collection('quiz')
    public = quiz_id in quizzes_ref.document('quiz-ids').get().to_dict()['public']

    names_ids = get_name_id_pair()
    results = []

    if public:
        quiz_ref = db.collection('quiz').document('public').collection(quiz_id)
        name = quiz_ref.document('setting').get().to_dict()['name']
        if quiz_ref.document('results').get().exists:
            quiz_results = quiz_ref.document('results').get().to_dict()
            for id in quiz_results.keys():
                results.append({
                    'student_name': names_ids[id],
                    'score': f'{quiz_results[id] * 100}%'
                })
    else:
        quiz_ref = db.collection('quiz').document('private').collection(quiz_id)
        name = quiz_ref.document('setting').get().to_dict()['name']
        if quiz_ref.document('results').get().exists:
            quiz_results = quiz_ref.document('results').get().to_dict()
            for id in quiz_results.keys():
                results.append({
                    'student_name': names_ids[id],
                    'score': f'{quiz_results[id] * 100}%'
                })

    return results, name
